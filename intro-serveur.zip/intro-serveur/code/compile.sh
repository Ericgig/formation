g++ HW.cpp -o HW.exe
mpic++ -fopenmp HW_mix.cpp -o HW_mix.exe
mpic++ HW_mpi.c -o HW_mpi.exe
g++ -fopenmp HW_omp.cpp -o HW_omp.exe
