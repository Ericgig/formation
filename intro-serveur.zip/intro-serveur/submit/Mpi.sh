#!/bin/bash
#SBATCH --time=00:10:00
#SBATCH --ntasks=8
#SBATCH --mem-per-cpu=1024M

srun ../code/HW_mpi.exe
