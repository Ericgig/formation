#include <iostream>
#include <string>

int main(){

std::string name;
std::cin >> name;
std::cout << "Hello " << name << "\n";

}
