from mpi4py import MPI

import sys
import math
import time

def approx_pi(intervals):
    pi = 0.0
    for i in range(intervals[0], intervals[1]):
        pi += (4 - 8 * (i % 2)) / (float)(2 * i + 1)
    return pi

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print >> sys.stderr, "usage: {0} <intervals>".format(sys.argv[0])
        sys.exit(1)

    t1 = time.time()

    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    n = int(sys.argv[1])
    chunk_size = n//size
    intervals = [[p*chunk_size, p*chunk_size+chunk_size] for p in range(size)]
    intervals[-1][1] = max(intervals[-1][1], n)

    myInterval = comm.scatter(intervals, root=0)

    partial_pi = approx_pi(myInterval)
    print("Rank", rank, "partial pi:", partial_pi)

    pi = comm.reduce(partial_pi, op=MPI.SUM, root=0)

    if rank == 0:
        t2 = time.time()
        print("PI is approximately %.16f, Error is %.16f"%(pi, abs(pi - math.pi)))
        print("Time = %.16f sec\n"%(t2 - t1))