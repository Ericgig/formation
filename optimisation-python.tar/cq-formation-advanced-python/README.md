# cq-formation-advanced-python
Advanced and Parallel Python workshop material
