#!/bin/bash
#PBS -l walltime=10:00:00
#PBS -l nodes=2:ppn=4

module use /cvmfs/opt.usherbrooke.ca/CentOS6/Modules/modulefiles.x86_64/
module load gcc openmpi_gcc64 MPI_Formation
cd code
mpiexec -n 2 ./HW_mix.exe
