#include <omp.h>
#include <iostream>
#include <sstream>

int main(){
int s=0;
#pragma omp parallel for
for( int i=1;i<=330000;++i){
   int a = i*5.15621+10.5151;
   if(i%101==2) s+=a;
}

//std::cout << s;
return 0;
}


