#include <omp.h>
#include <iostream>
#include <sstream>
#include <mpi.h>

int main(){
    MPI_Init(NULL, NULL);

    int size, rank;
    char processor_name[MPI_MAX_PROCESSOR_NAME];
    int len;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Get_processor_name(processor_name, &len);
    ++rank;

#pragma omp parallel 
{
        std::stringstream ss;
        ss << "Hello from " << processor_name << " thread " << omp_get_thread_num()+1 
           << " rank " << rank << "\n";
        std::cout << ss.str();
}
    MPI_Finalize();
}

