#!/bin/bash
#SBATCH --time=00:10:00
#SBATCH --account=??????????
#SBATCH --mem-per-cpu=128M

 
cd run
../code/HW.exe < in1 > out1 &
../code/HW.exe < in2 > out2 &
../code/HW.exe < in3 > out3 &
../code/HW.exe < in4 > out4 &
wait

