#!/bin/bash
#PBS -l walltime=00:10:00
#PBS -l nodes=2:ppn=1

module use /cvmfs/opt.usherbrooke.ca/CentOS6/Modules/modulefiles.x86_64/
module load gcc openmpi_gcc64 MPI_Formation
cd code
mpiexec -n 8 ./HW_mpi.exe
