#!/bin/bash
#PBS -l walltime=00:01:00
#PBS -l nodes=1:ppn=1
 
module use /cvmfs/opt.usherbrooke.ca/CentOS6/Modules/modulefiles.x86_64/
module load gcc
cd run
../code/HW.exe < in1 > out1 &
../code/HW.exe < in2 > out2 &
../code/HW.exe < in3 > out3 &
../code/HW.exe < in4 > out4 &
wait

