#!/bin/bash
#PBS -l walltime=00:01:00
#PBS -l nodes=1:ppn=1

module use /cvmfs/opt.usherbrooke.ca/CentOS6/Modules/modulefiles.x86_64/
module load gcc openmpi_gcc64
code/HW_omp.exe
