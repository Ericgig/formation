#!/bin/bash
#PBS -l walltime=00:02:00
#PBS -l nodes=1:ppn=1

module add gcc
cd par_test
time OMP_NUM_THREADS=1 ./test_long.exe 
time OMP_NUM_THREADS=2 ./test_long.exe 
time OMP_NUM_THREADS=4 ./test_long.exe 
time OMP_NUM_THREADS=8 ./test_long.exe 
time OMP_NUM_THREADS=12 ./test_long.exe
 
