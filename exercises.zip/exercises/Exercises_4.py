# -*- coding: utf-8 -*-
"""
@author: EG
"""

# 1 Faites les graphiques des statistique de tous les 720 patients