# -*- coding: utf-8 -*-
"""
@author: EG
"""

# 1 Utilisez "range" pour créer une loop qui écire 1,2,3

print(list(range(5)))
print(list(range(2,6)))
print(list(range(0,10,2)))

# 2 Créez une loop qui inverse un mot
# python -> nohtyp
# indice "a" + "b"

mot = "python"
